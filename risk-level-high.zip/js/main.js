$(document).ready(function () {
    $(".radio-btn li").click(function() {
        $(this).addClass('active');
        $('.radio-btn li').on('click', function() {
            $(this).addClass('active').siblings().removeClass('active');
        });
    });
    
});